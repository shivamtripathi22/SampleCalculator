# 📱 Calculator App — Android

A dark-themed Calculator app for Android, built with Kotlin. Auto-builds APK via GitHub Actions CI/CD.

## ✨ Features
- Addition, Subtraction, Multiplication, Division
- Percentage and Sign toggle
- Decimal support
- Dark iOS-style UI with orange operator buttons

## 🚀 How to Use

### Upload to GitHub & Auto-build APK

1. Create a new repo on [github.com/new](https://github.com/new)
2. Upload all these files (drag & drop into GitHub, or use git)
3. GitHub Actions will automatically build the APK
4. Go to **Actions** tab → latest run → **Artifacts** → download `calculator-debug-apk`

### Build Locally
```bash
chmod +x gradlew
./gradlew assembleDebug
# APK at: app/build/outputs/apk/debug/app-debug.apk
```

## 📋 Requirements
- Android 7.0+ (API 24)
- JDK 17 (for building)
