package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var tvResult: TextView
    private lateinit var tvExpression: TextView

    private var currentInput = ""
    private var operator = ""
    private var firstOperand = 0.0
    private var isNewInput = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvResult = findViewById(R.id.tvResult)
        tvExpression = findViewById(R.id.tvExpression)

        val numButtons = mapOf(
            R.id.btn0 to "0", R.id.btn1 to "1", R.id.btn2 to "2",
            R.id.btn3 to "3", R.id.btn4 to "4", R.id.btn5 to "5",
            R.id.btn6 to "6", R.id.btn7 to "7", R.id.btn8 to "8",
            R.id.btn9 to "9", R.id.btnDot to "."
        )
        numButtons.forEach { (id, digit) ->
            findViewById<Button>(id).setOnClickListener { appendDigit(digit) }
        }

        findViewById<Button>(R.id.btnPlus).setOnClickListener { setOperator("+") }
        findViewById<Button>(R.id.btnMinus).setOnClickListener { setOperator("−") }
        findViewById<Button>(R.id.btnMultiply).setOnClickListener { setOperator("×") }
        findViewById<Button>(R.id.btnDivide).setOnClickListener { setOperator("÷") }

        findViewById<Button>(R.id.btnEquals).setOnClickListener { calculate() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clear() }
        findViewById<Button>(R.id.btnSign).setOnClickListener { toggleSign() }
        findViewById<Button>(R.id.btnPercent).setOnClickListener { percent() }
    }

    private fun appendDigit(digit: String) {
        if (isNewInput) { currentInput = ""; isNewInput = false }
        if (digit == "." && currentInput.contains(".")) return
        if (digit == "." && currentInput.isEmpty()) currentInput = "0"
        currentInput += digit
        tvResult.text = currentInput
    }

    private fun setOperator(op: String) {
        if (currentInput.isNotEmpty()) firstOperand = currentInput.toDouble()
        operator = op
        tvExpression.text = "${formatNumber(firstOperand)} $op"
        isNewInput = true
    }

    private fun calculate() {
        if (operator.isEmpty() || currentInput.isEmpty()) return
        val second = currentInput.toDouble()
        val result = when (operator) {
            "+" -> firstOperand + second
            "−" -> firstOperand - second
            "×" -> firstOperand * second
            "÷" -> if (second != 0.0) firstOperand / second else Double.NaN
            else -> second
        }
        tvExpression.text = "${formatNumber(firstOperand)} $operator ${formatNumber(second)} ="
        tvResult.text = formatNumber(result)
        currentInput = result.toString()
        operator = ""
        isNewInput = true
    }

    private fun clear() {
        currentInput = ""; operator = ""; firstOperand = 0.0; isNewInput = false
        tvResult.text = "0"; tvExpression.text = ""
    }

    private fun toggleSign() {
        if (currentInput.isEmpty()) return
        val value = currentInput.toDouble() * -1
        currentInput = value.toString()
        tvResult.text = formatNumber(value)
    }

    private fun percent() {
        if (currentInput.isEmpty()) return
        val value = currentInput.toDouble() / 100
        currentInput = value.toString()
        tvResult.text = formatNumber(value)
    }

    private fun formatNumber(value: Double): String {
        return if (value == value.toLong().toDouble()) value.toLong().toString()
        else value.toString()
    }
}
